import tensorflow as tf

# Make a regression prediction
def predict_regression(model, X):
    return model.predict(X)
